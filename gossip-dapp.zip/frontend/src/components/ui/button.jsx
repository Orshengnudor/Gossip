export function Button({ onClick, children }) {
  return (
    <button
      onClick={onClick}
      className="bg-white text-purple-800 px-4 py-2 rounded hover:bg-purple-100 transition"
    >
      {children}
    </button>
  );
}
