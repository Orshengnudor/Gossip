import { useState, useEffect } from "react";
import { ethers } from "ethers";
import { Button } from "@/components/ui/button";

const contractAddress = "<DEPLOYED_CONTRACT_ADDRESS>";
const contractABI = [
  "function sendMessage() external",
  "function getRemainingMessages(address user) external view returns (uint256)"
];

export default function GossipApp() {
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [contract, setContract] = useState(null);
  const [account, setAccount] = useState("");
  const [remaining, setRemaining] = useState(0);
  const [status, setStatus] = useState("");

  useEffect(() => {
    const init = async () => {
      if (window.ethereum) {
        const _provider = new ethers.BrowserProvider(window.ethereum);
        await window.ethereum.request({ method: "eth_requestAccounts" });
        const _signer = await _provider.getSigner();
        const _account = await _signer.getAddress();
        const _contract = new ethers.Contract(contractAddress, contractABI, _signer);

        setProvider(_provider);
        setSigner(_signer);
        setAccount(_account);
        setContract(_contract);

        const rem = await _contract.getRemainingMessages(_account);
        setRemaining(Number(rem));
      }
    };
    init();
  }, []);

  const handleSendMessage = async () => {
    try {
      const tx = await contract.sendMessage();
      setStatus("Sending message...");
      await tx.wait();
      const rem = await contract.getRemainingMessages(account);
      setRemaining(Number(rem));
      setStatus("Message sent! You earned 0.01 MON.");
    } catch (err) {
      setStatus("Error: " + err.message);
    }
  };

  return (
    <div className="min-h-screen bg-purple-800 text-white flex items-center justify-center">
      <div className="p-6 max-w-lg w-full">
        <h1 className="text-2xl font-bold mb-4">🗣️ Gossip Chat Rewards</h1>
        <p className="mb-2">Connected as: {account}</p>
        <p className="mb-4">Remaining Messages Today: {remaining}</p>
        <Button onClick={handleSendMessage}>Send Message</Button>
        <p className="mt-4 text-sm text-gray-200">{status}</p>
      </div>
    </div>
  );
}